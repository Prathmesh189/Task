package com.example.flutter_p

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
