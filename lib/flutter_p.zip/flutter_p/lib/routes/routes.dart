class Routes {
  Routes._();

  static const SPLASH_SCREEN = '/splash_screen';

  static const DASHBOARD_SCREEN = '/dashboard_screen';
}
