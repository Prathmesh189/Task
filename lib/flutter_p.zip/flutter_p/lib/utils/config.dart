class Config {
  Config._();
  static String get appName => 'PROFCYMA';

  static String get domainUrl => 'http://milzac.node.profcymabackend.com:3002';
}
